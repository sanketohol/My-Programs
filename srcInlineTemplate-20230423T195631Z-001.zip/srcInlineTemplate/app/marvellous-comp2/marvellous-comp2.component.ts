import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-marvellous-comp2',
  template: `<h1>Inside Marvellous Component : Second</h1>`,
  styleUrls: ['./marvellous-comp2.component.css']
})
export class MarvellousComp2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
